Fist Make Data base:storyapp

then import the sql file on this data base