<?php 
	
	define("HOSTNAME","localhost");
	define("USERNAME","root");
	define("PASSWORD","");
	define("DBNAME","storyapp");
	$conn = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME);
	

 ?>